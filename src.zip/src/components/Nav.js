import React from 'react'
import './Nav.css'
import Logo from '../images/Logo.png'

import dashboard from '../images/dashboard.png'
import profile from '../images/profile.png'
import teams from '../images/teams.png'
import alarm from '../images/Alarm.png'
import logout from '../images/Logout.png'


 export default function Nav() {
   return (
     <nav className="nav">
       <div className='navbar-icon'>
         <div className='nav-logo'>
          <img  src={Logo} />
         </div>
         <p>CONNECTABILITY</p>
       </div>
       <div className='navbar-list'>
         <a className='navbar-list-item'>
           <img src={dashboard}></img>
           <p>Dashboard</p>
         </a>

         <a className='navbar-list-item'>
           <img src={profile}></img>
           <p>Profile</p>
         </a>

         <a className='navbar-list-item'>
           <img src={teams}></img>
           <p>Teams</p>
         </a>

         <a className='navbar-list-item'>
           <img src={alarm}></img>
           <p>Invitations</p>
         </a>

         <a className='navbar-list-item'>
           <img src={logout}></img>
           <p>Logout</p>
         </a>

       </div>
     </nav>
   )
 }
 