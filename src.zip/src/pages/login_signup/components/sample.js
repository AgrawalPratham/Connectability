import React from 'react'

export default function sample() {
  return (
    <div>sample</div>
  )
}
