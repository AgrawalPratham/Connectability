import React, { useState } from 'react';
import './mainform.css';

const Mainform = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isRightPanelActive, setRightPanelActive] = useState(false);

  const updateFormStep = (step) => {
    setCurrentStep(step);
  };

  const handleNext = () => {
    if (currentStep < 3) setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 0) setCurrentStep(currentStep - 1);
  };

  const handleSignUp = () => setRightPanelActive(true);
  const handleSignIn = () => setRightPanelActive(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    alert('Form submitted successfully!');
  };

  return (
    <div className={`container ${isRightPanelActive ? 'right-panel-active' : ''}`} id="container">

      <div className="form-container sign-up-container">
        <form onSubmit={handleSubmit} id="loginsignup">
          <div className={`form-step ${currentStep === 0 ? 'active' : ''}`}>
            <h1>Create Account</h1>
            <span>Enter your details to move forward</span>
            <input type="text" placeholder="Name" required />
            <input type="email" placeholder="Email" required />
            <input type="password" placeholder="Password" required />
            <div className="form-navigation">
              <button type="button" className="next-btn" onClick={handleNext}>
                Next
              </button>
            </div>
          </div>

          <div className={`form-step ${currentStep === 1 ? 'active' : ''}`}>
            <h1>Additional Details</h1>
            <input type="text" placeholder="Phone Number" />
            <input type="text" placeholder="Location" />
            <textarea placeholder="Tell us about yourself"></textarea>
            <div className="form-navigation">
              <button type="button" className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button type="button" className="next-btn" onClick={handleNext}>
                Next
              </button>
            </div>
          </div>

          <div className={`form-step ${currentStep === 2 ? 'active' : ''}`}>
            <h1>Social & Professional Links</h1>
            <input type="text" placeholder="GitHub Link" />
            <input type="text" placeholder="LinkedIn Profile" />
            <input type="text" placeholder="Resume Link" />
            <div className="form-navigation">
              <button type="button" className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button type="button" className="next-btn" onClick={handleNext}>
                Next
              </button>
            </div>
          </div>

          <div className={`form-step ${currentStep === 3 ? 'active' : ''}`}>
            <h1>Professional Experience</h1>
            <textarea placeholder="Past Experiences"></textarea>
            <input type="text" placeholder="Skills" />
            <div className="form-navigation">
              <button type="button" className="back-btn" onClick={handleBack}>
                Back
              </button>
              <button type="submit">Submit</button>
            </div>
          </div>
        </form>
      </div>

      <div className="form-container sign-in-container">
        <form action="#">
          <h1>Sign in</h1>
          <input type="email" placeholder="Email" />
          <input type="password" placeholder="Password" />
          <a href="#">Forgot your password?</a>
          <button>Sign In</button>
        </form>
      </div>

      <div className="overlay-container">
        <div className="overlay">
          <div className="overlay-panel overlay-left">
            <h1>Welcome Back!</h1>
            <p>To keep connected with us please login with your personal info</p>
            <button className="ghost" onClick={handleSignIn}>
              Sign In
            </button>
          </div>
          <div className="overlay-panel overlay-right">
            <h1>Hello, Friend!</h1>
            <p>Enter your personal details and start your journey with us</p>
            <button className="ghost" onClick={handleSignUp}>
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Mainform;
