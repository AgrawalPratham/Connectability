import React from 'react'
import './invitation.css'
import Nav from '../../components/Nav'
import NeedHelp from '../../components/needhelp.js'
import launch from '../../images/launchWhite.png'
import announcement from '../../images/announcementWhite.png'
import fire from '../../images/fireWhite.png'

export default function invitation() {
  return (
    <div className='invitation-page'>
         <div className='invitation-page-left'>
              <Nav />
              <NeedHelp />
        </div>
        
        <div className='invitation-page-right'>
  
          
            <div className='page-top-area'>
                <div className='top-link-area'>
                      <a href='#' className='top-link'>
                        <p>Trending</p>
                        <div className='top-link-image'>
                              <img src={fire}></img>
                        </div>
                      </a>
                      <a href='#' className='top-link'>
                        <p>Announcemenst</p>
                        <div className='top-link-image'>
                              <img src={announcement}></img>
                        </div>
                      </a>
                      <a href='#' className='top-link'>
                        <p>Hi Jignesh</p>
                        <div className='top-link-image'>
                              <img src={launch}></img>
                        </div>
                      </a>
                </div>
            </div>
           <div className='user-name-area'>
                <div className='user-image'>
                    {/* <img src='' ></img> */}
                </div>
                <div className='user-details'>
                    <h3>Jignesh</h3>
                    <p id='user-email'>esthera@simmple.com</p>
                </div>
            </div>
              
            <div className='user-invitation-area'>
                <h3>Yay! You Got 3 Invitations</h3>
                <hr></hr>
                <div className='invitation-area-headings'>
                    <p>PROJECTS</p>
                    <p>MEMBERS COUNT</p>
                    <p>BUDGET</p>
                    <p>CONFIRMATION</p>
                </div>
                  <hr className='horizontal-rule'></hr>
                <div className='user-individual-invitation'>
                    <p>Fitness Tracking App</p>
                    <p>4</p>
                    <p>15000</p>
                    <div className='confirmation-button-area'>
                        <button id='accept-button'>Accept</button>
                        <button id='reject-button'>Reject</button>
                    </div>

                </div>
                <hr className='horizontal-rule'></hr>

                  <div className='user-individual-invitation'>
                      <p>Fitness Tracking App</p>
                      <p>4</p>
                      <p>15000</p>
                      <div className='confirmation-button-area'>
                          <button id='accept-button'>Accept</button>
                          <button id='reject-button'>Reject</button>
                      </div>

                  </div>
                  <hr className='horizontal-rule'></hr>

                  

            </div>
        </div>
      
    </div>
  )
}
