import React from 'react'
import './projectDetailLeft.css'
import  image from '../../../images/mountain.png'
import github from '../../../images/GitHubBlack.png'

export default function projectDetailLeft() {
  return (
      <div className='project-content'>
            <div className='project-content-heading1'>
                <h3>Description</h3>
            </div>
            
            <div className='project-description'>
              <p>Lorem Ipsum is simply dummy text of the printing and  typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.

              when an  ssum passages, and more recently with desktop publishing software like Aldus PageMaker  including versions of Lorem IpsumLorem Ipsum is simply dummy text of the printing and  typesetting industry. Lorem Ipsum has been the industry.

              standard dummy text ever since the 1500s, when an  ssum passages, and more recently with desktop publishing software like Aldus PageMaker  including versions of Lorem IpsumLorem Ipsum is simply dummy text of the printing and  typesetting industry. 
              </p>
            </div>
            <a href=''>
                <div className='project-content-heading2'>
                    <h3>Project Git</h3>
                    <img src={github}></img>
                </div>
            </a>
            <div className='project-image'>
                <img src={image}></img>
            </div>
        </div>
  )
}
