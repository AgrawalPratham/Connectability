import React from 'react'
import './projectDetailRight.css'
import image from '../../../images/PrathamAgrawal.jpg'
import NeedHelp from '../../../components/needhelp.js'

export default function projectDetailRight() {
  return (
    <div className='right-container'>
      <div className='team-container'>
        <h3>Active Team</h3>

        <div className='leader-area'>
            <img src={image}></img>  
            <h4>Pratham Agrawal</h4>  
            <p>Leader</p>   
        </div>

        <div className='team-area'>
            <div className='individual-team-member'>
                <img src={image}></img>
                <h5>Pratham Agrawal</h5>  
            </div>

            <div className='individual-team-member'>
                <img src={image}></img>
                <h5>Pratham Agrawal</h5>
            </div>

            <div className='individual-team-member'>
                <img src={image}></img>
                <h5>Pratham Agrawal</h5>
            </div>

            <div className='individual-team-member'>
                <img src={image}></img>
                <h5>Pratham Agrawal</h5>
            </div>

                  <div className='individual-team-member'>
                      <img src={image}></img>
                      <h5>Pratham Agrawal</h5>
                  </div>

                  <div className='individual-team-member'>
                      <img src={image}></img>
                      <h5>Pratham Agrawal</h5>
                  </div>

                  <div className='individual-team-member'>
                      <img src={image}></img>
                      <h5>Pratham Agrawal</h5>
                  </div>

                  <div className='individual-team-member'>
                      <img src={image}></img>
                      <h5>Pratham Agrawal</h5>
                  </div>
        </div>
      </div>
      <div className='budget-needhelp-container'>
        <div className='budget-container'>
            <h3>Timeline</h3>
                  <h5>Start Date : </h5><p> 15515</p>
                  <br></br>
                  <h5>End Date : </h5><p> 15515</p>
                  <br></br>
                  <h5>Budget : </h5><p> 15515</p>
                  <br></br>
        </div>
        <div className='needhelp-container'>
            <NeedHelp />
        </div>
      </div>
      <div className='add-member-button-area'>
              <button className='add-member-button'> Add Members</button>
      </div>
    </div>
  )
}
