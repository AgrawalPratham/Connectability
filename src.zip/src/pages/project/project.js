import React, { useState, useRef } from 'react';
import './project.css';
import Nav from '../../components/Nav';
import launch from '../../images/launch.png';
import fire from '../../images/fire.png'
import announcement from '../../images/announcement.png'

import ProjectDetailLeft from './projectComponents/projectDetailLeft.js'
import ProjectDetailRight from './projectComponents/projectDetailRight.js'

export default function CreateProject() {

    return (
        <div className="project-page">
            <div className="project-left">
                <Nav />
            </div>
            <div className="project-right">
                <div className="project-top">
                    <div className="top-link-area">
                        <a href="#" className="top-link">
                            <p>Trending</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={fire} alt="Fire icon" />
                            </div>
                        </a>
                        <a href="#" className="top-link">
                            <p>Announcements</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={announcement} alt="Launch icon" />
                            </div>
                        </a>
                        <a href="#" className="top-link">
                            <p>Hi Jignesh</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={launch} alt="Launch icon" />
                            </div>
                        </a>
                    </div>
                </div>

                <div className='project-main'>
                    <div className='project-heading-area'>
                        <h2 className='project-heading'>Stock Price Prediction</h2>
                    </div>

                    <div className='project-detail-area'>
                        <div className='project-detail-left'>
                            <ProjectDetailLeft />
                        </div>
                        <div className='project-detail-right'>
                            <ProjectDetailRight />
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
}
