import React, { useState, useRef } from 'react';
import './createProject.css';
import Nav from '../../components/Nav';
import launch from '../../images/launch.png';
import fire from '../../images/fire.png'
import announcement from '../../images/announcement.png'

export default function CreateProject() {
  const [selectedSkills, setSelectedSkills] = useState([]);
  const [imageLinks, setImageLinks] = useState(['']); // Initial state with one empty link
  const allSkills = ['Frontend', 'Backend', 'App Dev', 'ML', 'React.js', 'Bootstrap', 'Angular.js', 'Golang'];

  // Allow dropping in both skill containers
  const allowDrop = (event) => {
    event.preventDefault();
  };

  // Handle dragging of items
  const handleDragStart = (event, skill, fromSelectedSkills) => {
    event.dataTransfer.setData("text", skill);
    event.dataTransfer.setData("fromSelectedSkills", fromSelectedSkills);
  };

  // Handle dropping of items
  const handleDrop = (event, toSelectedSkills) => {
    event.preventDefault();
    const skill = event.dataTransfer.getData("text");
    const fromSelectedSkills = event.dataTransfer.getData("fromSelectedSkills") === 'true';

    if (toSelectedSkills && !selectedSkills.includes(skill)) {
      setSelectedSkills((prevSkills) => [...prevSkills, skill]);
    } else if (!toSelectedSkills && selectedSkills.includes(skill)) {
      setSelectedSkills((prevSkills) => prevSkills.filter(s => s !== skill));
    }
  };

  // Handle image link changes
  const handleImageLinkChange = (index, event) => {
    const newImageLinks = [...imageLinks];
    newImageLinks[index] = event.target.value;
    setImageLinks(newImageLinks);
  };

  // Add a new image link field
  const addImageLinkField = () => {
    setImageLinks([...imageLinks, '']);
  };

  // Remove an image link field
  const removeImageLinkField = (index) => {
    const newImageLinks = imageLinks.filter((_, i) => i !== index);
    setImageLinks(newImageLinks);
  };

  // Handle form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Selected Skills:", selectedSkills);
    console.log("Image Links:", imageLinks);
    // Process form submission (e.g., send data to server)
  };

  return (
    <div className="create-project-page">
      <div className="create-project-left">
        <Nav />
      </div>
      <div className="create-project-right">
        <div className="create-project-top">
          <div className="top-link-area">
            <a href="#" className="top-link">
              <p>Trending</p>
              <div className="top-link-image">
                <img  className='top-link-image'  src={fire} alt="Fire icon" />
              </div>
            </a>
            <a href="#" className="top-link">
              <p>Announcements</p>
              <div className="top-link-image">
                <img className='top-link-image'  src={announcement} alt="Launch icon" />
              </div>
            </a>
            <a href="#" className="top-link">
              <p>Hi Jignesh</p>
              <div className="top-link-image">
                <img className='top-link-image'  src={launch} alt="Launch icon" />
              </div>
            </a>
          </div>
        </div>

        <div className="create-project-main">
          <div className="create-project-heading">
            <h3>Create Your Project</h3>
          </div>

          <div className="create-project-form">
            <form onSubmit={handleSubmit} className="create-project-form">
              <div className='form-input-area'>
                <div className='input-area-left'>
                  <label htmlFor="name">Project Name</label>
                  <input type="text" id="name" name="name" placeholder="Your project name" />

                  <label htmlFor="description">Description</label>
                  <textarea id="description" name="description" placeholder="Describe your project"></textarea>

                  <label htmlFor="github">Github Link</label>
                  <input type="text" id="github" name="github" placeholder="https://github.com/username/repo" />

                  <label>Image Links</label>
                  {imageLinks.map((link, index) => (
                    <div key={index} className="image-link-input">
                      <input
                        type="text"
                        value={link}
                        onChange={(event) => handleImageLinkChange(index, event)}
                        placeholder="Your Project image link"
                      />
                      <button
                        type="button" className='image-remove-button'
                        onClick={() => removeImageLinkField(index)}
                        disabled={imageLinks.length === 1}
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  <button type="button" className='image-add-button'  onClick={addImageLinkField}>
                    Add another link
                  </button>

                  <label htmlFor="start-date">Start Date</label>
                  <input type="date" id="start-date" name="start-date" />

                  <label htmlFor="budget">Budget</label>
                  <input type="number" id="budget" name="budget" placeholder="Enter Budget..." />

                  <label htmlFor="deadline">Deadline</label>
                  <input type="date" id="deadline" name="deadline" />

                  <label htmlFor="chatlink">Chat Link</label>
                  <input type="text" id="chatlink" name="chatlink" placeholder="WhatsApp link" />
                </div>

                <div className='input-area-right'>
                  <h3>Skill-Set Required</h3>
                  <div
                    id="skills-list"
                    className="skills-list"
                    onDrop={(event) => handleDrop(event, false)}
                    onDragOver={allowDrop}
                  >
                    {allSkills.filter(skill => !selectedSkills.includes(skill)).map(skill => (
                      <div
                        key={skill}
                        className="skill-item"
                        draggable="true"
                        onDragStart={(event) => handleDragStart(event, skill, false)}
                      >
                        {skill}
                      </div>
                    ))}
                  </div>

                  <h3>Selected Skills</h3>
                  <div
                    id="selected-skills"
                    className="selected-skills"
                    onDrop={(event) => handleDrop(event, true)}
                    onDragOver={allowDrop}
                  >
                    {selectedSkills.map(skill => (
                      <div
                        key={skill}
                        className="skill-item"
                        draggable="true"
                        onDragStart={(event) => handleDragStart(event, skill, true)}
                      >
                        {skill}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className='form-submit-button-area'>
                <button type="submit" className="publish-btn">Publish</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
