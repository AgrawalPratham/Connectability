import React, { useState, useRef } from 'react';
import './inviteMembers.css';
import Nav from '../../components/Nav';
import launch from '../../images/launch.png';
import fire from '../../images/fire.png'
import announcement from '../../images/announcement.png'

import MemberTile from './invite-membersComponents/memberTile.js'

export default function CreateProject() {
    
    return (
        <div className="invite-members-page">
            <div className="invite-members-left">
                <Nav />
            </div>
            <div className="invite-members-right">
                <div className="invite-members-top">
                    <div className="top-link-area">
                        <a href="#" className="top-link">
                            <p>Trending</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={fire} alt="Fire icon" />
                            </div>
                        </a>
                        <a href="#" className="top-link">
                            <p>Announcements</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={announcement} alt="Launch icon" />
                            </div>
                        </a>
                        <a href="#" className="top-link">
                            <p>Hi Jignesh</p>
                            <div className="top-link-image">
                                <img className='top-link-image' src={launch} alt="Launch icon" />
                            </div>
                        </a>
                    </div>
                </div>

                <div className='invite-members-main'>
                    <div className='invite-members-heading-area'>
                        <h2 className='invite-members-heading1'>Stock Price Prediction</h2>
                        <h3 className='invite-members-heading2'>Build Your Team</h3>
                    </div>
                    <div className='invite-members-tiles'>
                        <MemberTile/>
                        <MemberTile />
                        <MemberTile />
                        <MemberTile />
                        <MemberTile />
                        <MemberTile />
                        <MemberTile />
                    </div>
                </div>

            </div>
        </div>
    );
}
