import React from 'react'
import './memberTile.css'

import image from '../../../images/PrathamAgrawal.jpg'
import linkedin from '../../../images/LinkedIn.png'
import github from '../../../images/GitHub.png'
import resume from '../../../images/Resume.png'
import addUser from '../../../images/AddUser.png'

export default function memberTile() {
  return (
      <div className='individual-member-tile'>
          <div className='individual-member-image'>
              <img src={image}></img>
          </div>
          <div className='individual-member-details'>
              <h3>Pratham Agrawal</h3>
              <div className='member-skill-list'>
                <div className='member-skill'>React</div>
                <div className='member-skill'>React</div>
                <div className='member-skill'>React</div>
                <div className='member-skill'>React</div>
          <div className='member-skill'>React</div>
          <div className='member-skill'>React</div>
          <div className='member-skill'>React</div>
          <div className='member-skill'>React</div>
                  
              </div>
              <div className='member-links'>
                <a className='member-link' href='' ><img src={linkedin}></img></a>
                <a className='member-link' href='' ><img src={github}></img></a>
                <a className='member-link' href='' ><img src={resume}></img></a>
                <button className='invite-member-button'><img src={addUser}></img></button>
              </div>
          </div>
      </div>
  )
}
