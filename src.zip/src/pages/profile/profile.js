import React from 'react'
import './profile.css'
import Nav from '../../components/Nav'
import NeedHelp from '../../components/needhelp.js'
import launch from '../../images/launchWhite.png'
import announcement from '../../images/announcementWhite.png'
import fire from '../../images/fireWhite.png'

import linkedin from '../../images/LinkedIn.png'
import github from '../../images/GitHub.png'
import resume from '../../images/Resume.png'

export default function invitation() {
    return (
        <div className='invitation-page'>
            <div className='invitation-page-left'>
                <Nav />
                <NeedHelp />
            </div>

            <div className='invitation-page-right'>


                <div className='page-top-area'>
                    <div className='top-link-area'>
                        <a href='#' className='top-link'>
                            <p>Trending</p>
                            <div className='top-link-image'>
                                <img src={fire}></img>
                            </div>
                        </a>
                        <a href='#' className='top-link'>
                            <p>Announcemenst</p>
                            <div className='top-link-image'>
                                <img src={announcement}></img>
                            </div>
                        </a>
                        <a href='#' className='top-link'>
                            <p>Hi Jignesh</p>
                            <div className='top-link-image'>
                                <img src={launch}></img>
                            </div>
                        </a>
                    </div>
                </div>
                <div className='user-name-area'>
                    <div className='user-image'>
                        {/* <img src='' ></img> */}
                    </div>
                    <div className='user-details'>
                        <h3>Jignesh</h3>
                        <p id='user-email'>esthera@simmple.com</p>
                    </div>
                </div>

                <div className='user-detail-area'>
                    <div className='detail-area-left'>
                        <h2>Profile Information</h2>
                        <div className='user-profile-box'>
                            
                            <p>Hi, I’m Alec Thompson, Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).</p>
                            <p>Hi, I’m Alec Thompson, Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).</p>
                            <p>Hi, I’m Alec Thompson, Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).</p>
                            <p>Hi, I’m Alec Thompson, Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).</p>
                            <p>Hi, I’m Alec Thompson, Decisions: If you can’t decide, the answer is no. If two equally difficult paths, choose the one more painful in the short term (pain avoidance is creating an illusion of equality).</p>

                            <hr></hr>
                            <div className='user-personals'>
                                <p><span id="user-personals-heading">Name :</span> Arnam Chaurasiya</p>
                                <p><span id="user-personals-heading">Mobile :</span> 8451246785</p>
                                <p><span id="user-personals-heading">Email :</span> vhjejhevdhc@bbdhebdjk</p>
                                <p><span id="user-personals-heading">Location :</span> United States</p>
                                <p className='user-personal-links'>
                                    <span id="user-personals-heading">Links :</span> 
                                    <div className='user-personal-links-inner'>
                                        <a className='user-individual-link' href=''><img src={linkedin}></img></a>
                                        <a className='user-individual-link' href=''><img src={github}></img></a>
                                        <a className='user-individual-link' href=''><img src={resume}></img></a>
                                    </div>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className='detail-area-right'>
                        <div className='detail-right-above'>
                            <h2>Skills</h2>
                            <div className='user-skills'>
                                <div className='user-individual-skill'>React</div>
                                <div className='user-individual-skill'>Go</div>
                                <div className='user-individual-skill'>Machine Learning</div>
                                <div className='user-individual-skill'>Ai</div>
                                <div className='user-individual-skill'>React</div>
                                <div className='user-individual-skill'>Go</div>
                                <div className='user-individual-skill'>Machine Learning</div>
                                <div className='user-individual-skill'>React</div>
                                <div className='user-individual-skill'>Go</div>
                                <div className='user-individual-skill'>Machine Learning</div>
                                <div className='user-individual-skill'>Ai</div>
                                <div className='user-individual-skill'>React</div>
                                <div className='user-individual-skill'>Go</div>
                                <div className='user-individual-skill'>Machine Learning</div>

                                <div className='user-individual-skill'>Ai</div>
                            </div>
                        </div>
                        <div className='detail-right-below'>
                            <h2>Experience</h2>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>
                            <p>Built Weather Forcast React app , worked on api testinginful in the short term (pain avoidance is creating an illusion of equality)..</p>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}