import React from 'react'
import card2image from "../../../../images/mountain.png"
import "./card2.css"
export default function Cardy() {
  return (
    <div className='imagebox'>
        <div className='card2image'>
            <img src={card2image} alt="" />
        </div>
    </div>
  )
}
