import CreateProject from '../pages/create_project/createProject.js'
import Dashboard from '../pages/dashboard/dashboard.js'
import LoginSignup from '../pages/login_signup/loginsignup.js'
import Invitation from '../pages/invitation/invitation.js'
import InviteMembers from '../pages/invite_members/inviteMembers.js'
import Profile from '../pages/profile/profile.js' 
import Project from '../pages/project/project.js'

export const nav = [
    { path: "/",                name: "LoginSignup",        element: <LoginSignup />,       isPrivate: false },
    { path: "/dashboard",       name: "Dashboard",          element: <Dashboard />,         isPrivate: false },
    { path: "/invitation",      name: "Invitation",         element: <Invitation />,        isPrivate: false },
    { path: "/createproject",   name: "CreateProject",      element: <CreateProject />,     isPrivate: false },
    { path: "/invitemembers",   name: "InviteMembers",      element: <InviteMembers />,     isPrivate: false },
    { path: "/profile",         name: "Profile",            element: <Profile />,           isPrivate: false },
    { path: "/project",         name: "Project",            element: <Project />,           isPrivate: false }
]