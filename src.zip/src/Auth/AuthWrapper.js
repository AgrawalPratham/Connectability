import React, { createContext, useContext, useState } from 'react'
import RenderRoutes from './RenderRoutes';

const AuthContext = createContext();
export const AuthData = () => useContext(AuthContext)

export default function AuthWrapper() {

    const [user, setUser] = useState({ name: "", isAuthenticated: false })

    const login = (userName, password) => {

        //Call to authentication API to check the username

        return new Promise((resolve, reject) => {
            if (password === "password") {
                setUser({ name: userName, isAuthenticated: true })
                resolve("Success")
            } else {
                reject("Incorrect password")
            }
        })
    }

    const logout = () => {
        setUser({ ...user, isAuthenticated: false })
    }

    return (
        <AuthContext.Provider value={{ user, login, logout }}>
            <>
                <RenderRoutes />
            </>
        </AuthContext.Provider>
    )
}
